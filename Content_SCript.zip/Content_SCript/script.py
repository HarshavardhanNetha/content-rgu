import os
import subprocess

path = "/home/harsha/Documents/camtesia/PDS_1.1_VIDEO"
cmd = f"cd {path} && ls | grep mp4"
p = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
(output, err) = p.communicate()
p_status = p.wait()


def render_function():
    os.system(f"mv {path}/{video_list[0]} {path}/TEMPLATE.mp4")


def copy_template():
    os.system(f"cp -r TEMPLATE/* {path}/")

    folder_name = path.split("/")[-1]
    print(folder_name)
    os.system(f"mv {path}/TEMPLATE.html {path}/{folder_name}.html")


# print(output)
# print(output.split())
video_list = []
for i in output.split():
    a = str(i)
    # print(a[2:-1])
    video_list.append(a[2:-1])
print(video_list)

if(len(video_list) == 1):
    render_function()
    copy_template()
# elif(len(video_list) == 2):
#     pip_flag = 0
#     print("Video Length is 2")
#     for i in video_list:
#         if("PIP" in i ):
#             pipped_file = i
#             pip_flag = 1
#         else:
#             unpipped = i
#     if(pip_flag):
#         print(pipped_file, unpipped)
#         os.system(f"ffmpeg -i {path}/{pipped_file} -i {path}/{unpipped} {path}/TEMPLATE.mp4")
#         # ffmpeg -i right.mp4 -vf "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:-1:-1:color=black" right_new.mp4
# 		# ffmpeg -i right_PIP.mp4 -vf "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:-1:-1:color=black" right_new_PIP.mp4

# 		# ffmpeg -i right_new_PIP.mp4 -i right_new.mp4  -filter_complex hstack TEMPLATE.mp4

#         #mmpeg left right mp4 render funtion
#         #print("More than one video")
#     # render_function()
#     copy_template()
